"""Collect visible USTSpace course-page snapshots after the owner logs in locally.
No passwords, request headers, cookies, API tokens or HAR files are exported.
Actual USTSpace compatibility requires a first-course check on the user's machine.
"""
import argparse,json,re,time,sys
from datetime import datetime,timezone
from pathlib import Path
from urllib.parse import urlparse,urlunparse,parse_qsl,urlencode,urljoin
from urllib.robotparser import RobotFileParser

KIND='ustspace-visible-snapshots'
VERSION='2026.11.03.2'
CODE=re.compile(r'^[A-Z]{4}\d{4}[A-Z]?$')
REDACT_EMAIL=re.compile(r'[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}',re.I)
class AccessStop(Exception):pass
class LoginRequired(AccessStop):pass
class CourseUnavailable(Exception):pass

def utc():return datetime.now(timezone.utc).isoformat()
def codes_from(path):
 value=json.loads(Path(path).read_text(encoding='utf-8-sig'))
 rows=value.get('courseCodes',[]) if isinstance(value,dict) else value
 if not isinstance(rows,list):raise ValueError('courseCodes must be an array')
 codes=[];excluded=[]
 for raw in rows:
  code=re.sub(r'\s','',str(raw)).upper()
  if CODE.fullmatch(code):
   if code not in codes:codes.append(code)
  else:excluded.append(code)
 return codes,excluded

def official_url(url):
 p=urlparse(url)
 return p.scheme=='https' and (p.hostname=='ust.space' or (p.hostname or '').endswith('.ust.space')) and not p.username and not p.password

def source_url(url):
 if not official_url(url):raise AccessStop('Unexpected source host; collection stopped.')
 p=urlparse(url)
 return urlunparse((p.scheme,p.netloc,p.path,'','',''))

def derive_template(url,code):
 if not official_url(url):return None
 p=urlparse(url)
 allowed={'course','code','coursecode','subject','department','term','semester'}
 if any(k.lower() not in allowed for k,v in parse_qsl(p.query)):return None
 compact=code[:4]+code[4:]
 candidates=[(compact,'{course}'),(code[:4]+'%20'+code[4:],'{subject}%20{number}'),(code[:4]+'-'+code[4:],'{subject}-{number}'),(code[:4]+'/'+code[4:],'{subject}/{number}')]
 for pattern,replacement in candidates:
  if re.search(re.escape(pattern),url,re.I):return re.sub(re.escape(pattern),replacement,url,flags=re.I)
 return None

def render_template(template,code):
 return template.replace('{course}',code).replace('{subject}',code[:4]).replace('{number}',code[4:])

def page_has_code(text,code):
 return bool(re.search(r'(?<![A-Z0-9])'+code[:4]+r'[\s/-]*'+code[4:]+r'(?![A-Z0-9])',text,re.I))

def clean_visible(text):
 # Only rendered page text is collected. Hide email-like strings and obvious
 # inline credential fields in case a site unexpectedly renders them.
 text=REDACT_EMAIL.sub('[email removed]',text)
 lines=[line for line in text.splitlines() if not re.search(r'(?:authorization|access[_ -]?token|refresh[_ -]?token|password|cookie)\s*[:=]',line,re.I)]
 return '\n'.join(lines).strip()

def add_chunk(chunks,text):
 if not text or any(text in old for old in chunks):return chunks
 return [old for old in chunks if old not in text]+[text]

def check_access(page,status=None):
 # title() performs a browser round-trip. page.url alone is cached while the
 # synchronous Python input() prompt is blocking Playwright event delivery.
 title=page.title()
 status=status or getattr(page,'_collector_blocked_status',None) or getattr(getattr(page,'context',None),'_collector_blocked_status',None)
 if status in (401,403,429):raise AccessStop(f'Access/rate-limit response {status}; no retries or bypass attempted.')
 if re.search(r'just a moment|attention required|checking your browser|verify.*human',title,re.I):raise AccessStop('Browser challenge encountered; collection stopped.')
 if re.search(r'/(?:login|signin|sign-in|auth|register)(?:[/?#]|$)',page.url,re.I):raise LoginRequired('LOGIN_URL')

def visible_text(page,selector,code):
 loc=page.locator(selector).first
 if not loc.count():
  # When the site has no semantic main element, keep only the part after the
  # requested course heading, rather than the account/navigation header.
  raw=page.locator('body').inner_text()
  match=re.search(re.escape(code[:4])+r'\s*'+re.escape(code[4:]),raw,re.I)
  if not match:raise CourseUnavailable('Requested course code was not visible on this page.')
  raw=raw[match.start():]
 else:raw=loc.inner_text()
 if re.search(r'please (?:log|sign) in|log in to (?:view|read)|sign in to (?:view|read)|登入後.*(?:查看|閱讀)|登录后.*(?:查看|阅读)',raw,re.I):raise LoginRequired('LOGIN_TEXT')
 if not page_has_code(raw,code):raise CourseUnavailable('Course page did not display the requested course code.')
 return clean_visible(raw)

def wait_for_first_course(page,code,selector,input_fn=input,print_fn=print):
 # Only the owner interacts with login. Enter checks readiness; it does not
 # submit credentials or retry blocked requests. Keep this browser available
 # after an early Enter so that a zero-row file is not mistaken for success.
 from playwright.sync_api import Error as BrowserError
 context=page.context
 while True:
  input_fn(f'请在此工具打开的浏览器完成登录，并打开 {code} 的课程评价详情页；完成后回到这里按 Enter（Ctrl+C 退出）: ')
  # Pump pending browser events BEFORE reading cached URLs, closed state or
  # context.pages. A user may have navigated, opened a tab, or closed the initial
  # login tab while input() blocked Python. No page reload or login submission.
  for probe in [page]+list(context.pages):
   try:
    probe.wait_for_timeout(200)
    break
   except BrowserError:continue
  candidates=[tab for tab in reversed(context.pages) if not tab.is_closed()]
  if not candidates:raise AccessStop('All collector browser tabs were closed. Restart the collector to continue.')
  print_fn(f'检查工具浏览器中的 {len(candidates)} 个标签页（网址已去掉查询参数和片段）：')
  for index,tab in enumerate(candidates,1):
   if not official_url(tab.url):
    print_fn(f'  标签页 {index}: 非 USTSpace 页面，跳过。')
    continue
   label=source_url(tab.url)
   try:
    check_access(tab)
    if not official_url(tab.url):continue
    label=source_url(tab.url)
    visible_text(tab,selector,code)
   except LoginRequired as error:
    reason='网址仍指向登录页 [LOGIN_URL]' if str(error)=='LOGIN_URL' else '页面文字触发登录提示检测 [LOGIN_TEXT]'
    print_fn(f'  标签页 {index}: {source_url(tab.url)} — {reason}')
    continue
   except CourseUnavailable:
    print_fn(f'  标签页 {index}: {label} — 尚未看到 {code} 的课程内容 [COURSE_NOT_FOUND]')
    continue
   except BrowserError:
    print_fn(f'  标签页 {index}: 页面正在跳转、加载或已关闭 [PAGE_CHANGING]')
    continue
   print_fn(f'已选中标签页 {index}: {label}；页面显示 {code}。开始检查采集条件，导出内容仍需核对。')
   return tab
  print_fn('暂未找到可采集的课程页；浏览器将保持打开。请在工具浏览器内打开指定课程后再按 Enter。如果你已能看到评价，请提供上面的诊断行。')

def next_control(page,pattern):
 for role in ['button','link']:
  loc=page.get_by_role(role,name=pattern)
  for i in range(min(loc.count(),10)):
   candidate=loc.nth(i)
   if candidate.is_visible() and candidate.is_enabled() and candidate.get_attribute('aria-disabled')!='true':return candidate
 return None

def load_more(page,args):
 previous='';stable=0
 for _ in range(args.max_scrolls):
  check_access(page)
  button=next_control(page,re.compile(r'^(?:load more(?: reviews)?|show more reviews|more reviews|載入更多(?:評價)?|加载更多(?:评价)?|更多評價|更多评价)$',re.I))
  if button:button.click()
  else:page.evaluate('window.scrollTo(0, document.body.scrollHeight)')
  page.wait_for_timeout(args.delay*1000)
  text=page.locator('body').inner_text()
  if text==previous:stable+=1
  else:stable=0
  previous=text
  if stable>=2:break

def collect_current(page,code,args):
 chunks=[];pages=0;seen=set()
 for index in range(args.max_pages):
  check_access(page)
  initial=visible_text(page,args.content_selector,code)
  if initial in seen:break
  seen.add(initial);chunks=add_chunk(chunks,initial)
  load_more(page,args)
  chunks=add_chunk(chunks,visible_text(page,args.content_selector,code));pages+=1
  if sum(map(len,chunks))>240000:break
  button=next_control(page,re.compile(r'^(?:next(?: page)?|下一頁|下一页|下頁|下页)$',re.I))
  if not button:break
  button.click();page.wait_for_timeout(args.delay*1000)
 text='\n\n--- visible page snapshot ---\n\n'.join(chunks)
 if len(text)>250000:text=text[:250000]
 return {'courseCode':code,'status':'captured','sourceUrl':source_url(page.url),'capturedAt':utc(),'text':text,'visiblePagesCaptured':pages,'completeness':'visible-content-only','note':'Rendered page evidence only; may include course descriptions and navigation. Pagination/scroll limits and website visibility mean this is not guaranteed to contain all reviews. No rating or syllabus tags were inferred.'}

def navigate_course(page,code,args,template):
 if template:
  target=render_template(template,code)
  if not official_url(target):raise AccessStop('Course template points outside USTSpace.')
  response=page.goto(target,wait_until='domcontentloaded',timeout=45000)
  page.wait_for_timeout(args.delay*1000);check_access(page,response.status if response else None);return page
 if args.manual:
  return wait_for_first_course(page,code,args.content_selector)
 response=page.goto('https://ust.space/review',wait_until='domcontentloaded',timeout=45000)
 page.wait_for_timeout(args.delay*1000);check_access(page,response.status if response else None)
 if args.search_selector:search=page.locator(args.search_selector).first
 else:
  search=page.get_by_role('searchbox').first
  if not search.count():search=page.get_by_placeholder(re.compile(r'search|搜尋|搜索|搜尋課程|搜索课程',re.I)).first
 if not search.count():raise CourseUnavailable('No known search control. Restart with --manual or a verified --search-selector; no routes were guessed.')
 search.fill(code);page.wait_for_timeout(args.delay*1000)
 pattern=re.compile(re.escape(code[:4])+r'\s*'+re.escape(code[4:]),re.I)
 link=page.get_by_role('link',name=pattern).first
 if not link.count():raise CourseUnavailable('Search did not expose a course link. No data was fabricated.')
 href=link.get_attribute('href')
 if href:
  target=urljoin(page.url,href)
  if not official_url(target):raise AccessStop('Search result points outside USTSpace.')
  response=page.goto(target,wait_until='domcontentloaded',timeout=45000)
  page.wait_for_timeout(args.delay*1000);check_access(page,response.status if response else None)
 else:link.click();page.wait_for_timeout(args.delay*1000);check_access(page)
 return page

def partition_rows(rows,max_bytes=8*1024*1024):
 parts=[];current=[];size=0
 for row in rows:
  n=len(json.dumps(row,ensure_ascii=False).encode('utf-8'))+2
  if current and size+n>max_bytes:parts.append(current);current=[];size=0
  current.append(row);size+=n
 if current:parts.append(current)
 return parts

def save(output,rows,excluded,stopped):
 document={'schemaVersion':1,'kind':KIND,'collectorVersion':VERSION,'capturedAt':utc(),'courses':rows,'excludedCodes':excluded,'stoppedBecause':stopped,'capturedCount':sum(r['status']=='captured' for r in rows),'attemptedCount':len(rows),'completeness':'visible-content-only; not guaranteed complete reviews'}
 output.parent.mkdir(parents=True,exist_ok=True)
 parts=partition_rows(rows)
 if len(parts)>1:
  document['importParts']=[]
  for i,part in enumerate(parts,1):
   path=output.with_name(output.stem+f'.part-{i:03d}.json')
   value={**document,'courses':part,'capturedCount':sum(r['status']=='captured' for r in part),'attemptedCount':len(part)}
   value.pop('importParts',None)
   path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
   document['importParts'].append(path.name)
 temporary=output.with_suffix('.tmp');temporary.write_text(json.dumps(document,ensure_ascii=False,indent=2),encoding='utf-8');temporary.replace(output)

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--version',action='version',version='CoursePilot collector '+VERSION)
 ap.add_argument('--courses',default='coursepilot-course-codes.json');ap.add_argument('--output',default='ustspace-snapshots.json');ap.add_argument('--profile',default='.ustspace-local-session')
 ap.add_argument('--limit',type=int,default=3,help='First-run cap. Use 0 for all supplied course codes only after checking the three-course output.')
 ap.add_argument('--delay',type=float,default=4);ap.add_argument('--max-scrolls',type=int,default=8);ap.add_argument('--max-pages',type=int,default=20)
 ap.add_argument('--content-selector',default='main');ap.add_argument('--search-selector');ap.add_argument('--url-template');ap.add_argument('--manual',action='store_true');ap.add_argument('--channel',default=None)
 args=ap.parse_args()
 print('CoursePilot collector '+VERSION+' — 浏览器状态刷新 / 多标签页识别',flush=True)
 if args.limit<0 or args.delay<3 or not 1<=args.max_pages<=100 or not 1<=args.max_scrolls<=50:ap.error('limit must be non-negative; delay >=3 seconds; pages 1–100; scrolls 1–50.')
 codes,excluded=codes_from(args.courses)
 if not codes:ap.error('No unambiguous course codes were supplied.')
 if args.limit:codes=codes[:args.limit]
 output=Path(args.output).resolve();rows=[];stopped=None
 if output.exists():
  backup=output.with_name(output.stem+'.backup-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+output.suffix)
  output.replace(backup);print('Previous output preserved as '+backup.name,flush=True)
 print(f'{len(codes)} course(s) selected; {len(excluded)} invalid code(s) skipped. First course: {codes[0]}',flush=True)
 print('Only collect pages your account may normally access, in accordance with the site rules. This tool does not bypass access controls.',flush=True)
 from playwright.sync_api import sync_playwright
 with sync_playwright() as p:
  options={'user_data_dir':str(Path(args.profile).resolve()),'headless':False,'accept_downloads':False,'viewport':{'width':1280,'height':900}}
  if args.channel:options['channel']=args.channel
  context=p.chromium.launch_persistent_context(**options)
  page=context.pages[0] if context.pages else context.new_page()
  def observe(response):
   if official_url(response.url) and response.status in (401,403,429) and response.request.resource_type in ('document','xhr','fetch'):
    context._collector_blocked_status=response.status
  context.on('response',observe)
  try:
   page.goto('https://ust.space/review',wait_until='domcontentloaded',timeout=45000)
   print('\nIn the opened browser, log in yourself. Do not paste credentials into this terminal or chat.',flush=True)
   page=wait_for_first_course(page,codes[0],args.content_selector)
   # Read robots through the same normal browser context, without exporting auth.
   robots=RobotFileParser();response=context.request.get('https://ust.space/robots.txt',timeout=20000)
   if response.status==200:robots.parse(response.text().splitlines())
   elif response.status==404:robots.parse([])
   else:raise AccessStop(f'Cannot establish robots policy (HTTP {response.status}); automatic collection stopped.')
   template=args.url_template or (None if args.manual else derive_template(page.url,codes[0]))
   if template and not ('{course}' in template or '{subject}' in template and '{number}' in template):raise ValueError('URL template must contain {course}, or both {subject} and {number}.')
   if not template and not args.manual:print('No course route template was observed; subsequent courses will use visible search controls. If unavailable, use --manual.',flush=True)
   for index,code in enumerate(codes):
    if not robots.can_fetch('CoursePilotResearchSnapshot',page.url if index==0 else render_template(template,code) if template else 'https://ust.space/review'):
     raise AccessStop('robots.txt disallows the requested path; collection stopped.')
    try:
     if index:page=navigate_course(page,code,args,template)
     if not robots.can_fetch('CoursePilotResearchSnapshot',page.url):raise AccessStop('robots.txt disallows the observed course path; collection stopped.')
     record=collect_current(page,code,args);rows.append(record)
     print(code+': captured visible page evidence (not a verified review count).',flush=True)
    except AccessStop:raise
    except CourseUnavailable as e:
     rows.append({'courseCode':code,'status':'unavailable','reason':str(e),'capturedAt':utc()});print(code+': unavailable; recorded without invented data.',flush=True)
     if sum(r['status']=='unavailable' for r in rows[-3:])==3:raise AccessStop('Three consecutive courses unavailable; check the website structure before continuing.')
    except Exception as e:
     rows.append({'courseCode':code,'status':'failed','reason':type(e).__name__,'capturedAt':utc()});print(code+': failed ('+type(e).__name__+').',flush=True)
     raise AccessStop('Unexpected page error; partial results saved. Check website structure before retrying.')
    save(output,rows,excluded,None);time.sleep(args.delay)
  except KeyboardInterrupt:stopped='Stopped by user.'
  except (AccessStop,CourseUnavailable,ValueError) as e:stopped=str(e);print('STOP: '+stopped,flush=True)
  except Exception as e:stopped='Setup/navigation failed: '+type(e).__name__;print('STOP: '+stopped,flush=True)
  finally:
   save(output,rows,excluded,stopped);context.close()
 print(f'Saved {sum(r["status"]=="captured" for r in rows)}/{len(rows)} attempted course snapshots to {output.name}.',flush=True)
 if not any(r['status']=='captured' for r in rows):print('未采集到任何课程页面。此 JSON 仅记录停止原因，不含评价；请检查上方提示后再运行。',flush=True)
 if len(partition_rows(rows))>1:print('Large export: import the generated .part-001.json, .part-002.json, etc. separately; the complete export is also retained.',flush=True)
 if stopped:return 2
 return 0
if __name__=='__main__':sys.exit(main())
