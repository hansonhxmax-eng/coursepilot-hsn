@echo off
call "%~dp0Start-Windows.bat" --all
exit /b %errorlevel%
